﻿'Author:	   	 Brennan Kerr
'Date:		     January 15th, 2019
'File Name:		 AverageUnitsShipped
'Project Name:	 Lab 1 - Average Units Shipped
'Description:	 Takes user input for a given week and displays the average

Public Class Form1
	'Constants-----------------------------------------------------------------------------------------------
	Const MaxDays As Integer = 7                'The constant max number that can be entered

	'Veriables-----------------------------------------------------------------------------------------------
	Dim unitsShipped(MaxDays - 1) As Integer    'Creates an array used to store the inputted whole numbers
	Dim day As Integer = 0                      'Counts to determine which day has been entered
	Dim sum As Integer = 0                      'Adds all the days
	Dim average As Double                       'Calculates the average

	'Runs once "btnEnter" has been pressed
	Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
		'Clear the output label
		lbOutput.Text = ""

		'If the input is a whole number, save it to the current day in the array
		'Display the input into the output textbox called "tbOutput"
		If Integer.TryParse(tbInput.Text, unitsShipped(day)) Then
			'Check to see if the input is in range
			If 0 <= unitsShipped(day) And unitsShipped(day) <= 1000 Then
				day = day + 1
				tbOutput.Text = tbOutput.Text + tbInput.Text + Environment.NewLine

				'Adds the current input into "sum"
				sum = sum + tbInput.Text

				'If the number is out of range
			Else
				lbOutput.ForeColor = Color.Red
				lbOutput.Text = "Invalid Input" + Environment.NewLine + "Please enter a number between 0 and 1000"
			End If

			'If the input was not a whole number
			'Display an error message in red
		Else
			lbOutput.ForeColor = Color.Red
			lbOutput.Text = "Invalid Input" + Environment.NewLine + "Please enter a whole number!"
		End If

		'Clear the input textbox
		tbInput.Text = ""

		'If a full week has been entered, disable input
		If day = MaxDays Then
			tbInput.ReadOnly = True
			btnEnter.Enabled = False

			'Keep day at 6
			day = 6

			'Changes the text colour to Black
			lbOutput.ForeColor = Color.Black

			'Display the average
			average = Math.Round(sum / MaxDays, 2)
			lbOutput.Text = "Average Units Shipped:" + average.ToString()
		End If

		'Resets the input label to display the current day
		lbInput.Text = "Units Shipped on Day " + (day + 1).ToString() + ":"

	End Sub

	'Runs once "btnReset" has been pressed
	Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
		'Enable input to all functions
		tbInput.ReadOnly = False
		btnEnter.Enabled = True

		'Clear any text
		tbInput.Text = ""
		tbOutput.Text = ""
		lbOutput.Text = ""

		'Reset the input label
		lbInput.Text = "Units Shipped on Day 1:"

		'Sets day and sum back to 0
		day = 0
		sum = 0

		'Sets the input textbox as the first index once reset
		tbInput.Select()
	End Sub

	'Runs once "btnExit" has been pressed
	'Closes the application
	Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
		Close()
	End Sub
End Class
