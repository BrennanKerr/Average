﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.tblLayout = New System.Windows.Forms.TableLayoutPanel()
		Me.pnInput = New System.Windows.Forms.Panel()
		Me.tbInput = New System.Windows.Forms.TextBox()
		Me.lbInput = New System.Windows.Forms.Label()
		Me.tbOutput = New System.Windows.Forms.TextBox()
		Me.lbOutput = New System.Windows.Forms.Label()
		Me.btnEnter = New System.Windows.Forms.Button()
		Me.btnReset = New System.Windows.Forms.Button()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.tblLayout.SuspendLayout()
		Me.pnInput.SuspendLayout()
		Me.SuspendLayout()
		'
		'tblLayout
		'
		Me.tblLayout.ColumnCount = 5
		Me.tblLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.002!))
		Me.tblLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.66533!))
		Me.tblLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.66533!))
		Me.tblLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.66533!))
		Me.tblLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.002!))
		Me.tblLayout.Controls.Add(Me.pnInput, 1, 0)
		Me.tblLayout.Controls.Add(Me.tbOutput, 1, 1)
		Me.tblLayout.Controls.Add(Me.lbOutput, 1, 2)
		Me.tblLayout.Controls.Add(Me.btnEnter, 1, 3)
		Me.tblLayout.Controls.Add(Me.btnReset, 2, 3)
		Me.tblLayout.Controls.Add(Me.btnExit, 3, 3)
		Me.tblLayout.Dock = System.Windows.Forms.DockStyle.Fill
		Me.tblLayout.Location = New System.Drawing.Point(0, 0)
		Me.tblLayout.Name = "tblLayout"
		Me.tblLayout.RowCount = 4
		Me.tblLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
		Me.tblLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
		Me.tblLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
		Me.tblLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
		Me.tblLayout.Size = New System.Drawing.Size(306, 288)
		Me.tblLayout.TabIndex = 0
		'
		'pnInput
		'
		Me.tblLayout.SetColumnSpan(Me.pnInput, 3)
		Me.pnInput.Controls.Add(Me.tbInput)
		Me.pnInput.Controls.Add(Me.lbInput)
		Me.pnInput.Dock = System.Windows.Forms.DockStyle.Fill
		Me.pnInput.Location = New System.Drawing.Point(33, 3)
		Me.pnInput.Name = "pnInput"
		Me.pnInput.Size = New System.Drawing.Size(237, 22)
		Me.pnInput.TabIndex = 0
		'
		'tbInput
		'
		Me.tbInput.Location = New System.Drawing.Point(130, 1)
		Me.tbInput.Name = "tbInput"
		Me.tbInput.Size = New System.Drawing.Size(107, 20)
		Me.tbInput.TabIndex = 1
		Me.ToolTip1.SetToolTip(Me.tbInput, "Enter the current days number of units shipped." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Must be a whole number and be in" &
		"between 0 and 1000 inclusive.")
		'
		'lbInput
		'
		Me.lbInput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lbInput.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.lbInput.Location = New System.Drawing.Point(0, 1)
		Me.lbInput.Name = "lbInput"
		Me.lbInput.Size = New System.Drawing.Size(124, 22)
		Me.lbInput.TabIndex = 0
		Me.lbInput.Text = "Units Shipped on Day 1:"
		'
		'tbOutput
		'
		Me.tblLayout.SetColumnSpan(Me.tbOutput, 3)
		Me.tbOutput.Dock = System.Windows.Forms.DockStyle.Fill
		Me.tbOutput.Location = New System.Drawing.Point(33, 31)
		Me.tbOutput.Multiline = True
		Me.tbOutput.Name = "tbOutput"
		Me.tbOutput.ReadOnly = True
		Me.tbOutput.Size = New System.Drawing.Size(237, 195)
		Me.tbOutput.TabIndex = 1
		Me.tbOutput.TabStop = False
		Me.ToolTip1.SetToolTip(Me.tbOutput, "Displays each days input.")
		'
		'lbOutput
		'
		Me.lbOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.tblLayout.SetColumnSpan(Me.lbOutput, 3)
		Me.lbOutput.Dock = System.Windows.Forms.DockStyle.Fill
		Me.lbOutput.Location = New System.Drawing.Point(33, 229)
		Me.lbOutput.Name = "lbOutput"
		Me.lbOutput.Size = New System.Drawing.Size(237, 28)
		Me.lbOutput.TabIndex = 0
		Me.lbOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.ToolTip1.SetToolTip(Me.lbOutput, "Displays the average number of units shipped." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Will also display an error message" &
		" if the input is not a whole number.")
		'
		'btnEnter
		'
		Me.btnEnter.Location = New System.Drawing.Point(33, 260)
		Me.btnEnter.Name = "btnEnter"
		Me.btnEnter.Size = New System.Drawing.Size(75, 23)
		Me.btnEnter.TabIndex = 1
		Me.btnEnter.Text = "&Enter"
		Me.ToolTip1.SetToolTip(Me.btnEnter, "Click to enter the input." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Can be accessed by pressing Enter or Alt+E.")
		Me.btnEnter.UseVisualStyleBackColor = True
		'
		'btnReset
		'
		Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnReset.Location = New System.Drawing.Point(114, 260)
		Me.btnReset.Name = "btnReset"
		Me.btnReset.Size = New System.Drawing.Size(75, 23)
		Me.btnReset.TabIndex = 2
		Me.btnReset.Text = "&Reset"
		Me.ToolTip1.SetToolTip(Me.btnReset, "Reset the window and clear all input." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Can be accessed by pressing Esc or Alt+R.")
		Me.btnReset.UseVisualStyleBackColor = True
		'
		'btnExit
		'
		Me.btnExit.Location = New System.Drawing.Point(195, 260)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(75, 23)
		Me.btnExit.TabIndex = 3
		Me.btnExit.Text = "E&xit"
		Me.ToolTip1.SetToolTip(Me.btnExit, "Click to exit the application." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Can be accessed by pressing Alt+X.")
		Me.btnExit.UseVisualStyleBackColor = True
		'
		'Form1
		'
		Me.AcceptButton = Me.btnEnter
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.CancelButton = Me.btnReset
		Me.ClientSize = New System.Drawing.Size(306, 288)
		Me.Controls.Add(Me.tblLayout)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "Form1"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Average Units Shipped"
		Me.tblLayout.ResumeLayout(False)
		Me.tblLayout.PerformLayout()
		Me.pnInput.ResumeLayout(False)
		Me.pnInput.PerformLayout()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents tblLayout As TableLayoutPanel
	Friend WithEvents pnInput As Panel
	Friend WithEvents tbInput As TextBox
	Friend WithEvents lbInput As Label
	Friend WithEvents ToolTip1 As ToolTip
	Friend WithEvents tbOutput As TextBox
	Friend WithEvents lbOutput As Label
	Friend WithEvents btnEnter As Button
	Friend WithEvents btnReset As Button
	Friend WithEvents btnExit As Button
End Class
